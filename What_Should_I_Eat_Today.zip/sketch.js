//variables
let regular;
let sad;
let happy;
let sandvich;
let banana;
let pepper;
let steam;
let fontRegular;
let small;
let big;
let img;
let angry;
let fire;

function preload(){
  //preload images
  regular = loadImage('assets/normal.png');
  sad = loadImage('assets/sad.png');
  happy = loadImage('assets/blush.png');
  banana = loadImage('assets/second banana 2.png');
  pepper = loadImage('assets/dr pepper.png');
  sandvich = loadImage('assets/sandvich.png')
  steam = loadImage('assets/steamhappy.png')
  fontRegular = loadFont('/assets/DiaryOfAn8BitMage.ttf');
  small = loadImage('assets/small.png');
  big = loadImage('assets/big.png');
  img = loadImage('assets/second banana 2.png');
  crab = loadImage('assets/klutzycrab.png')
  angry = loadImage('assets/angry.png')
  fire = loadImage('assets/fire.png')
  fort = loadImage('assets/2fort.png')
}

function setup() {
  createCanvas(900, 900);
  frameRate(60);
  colorMode(RGB);
}

function draw() {
  image(fort, 0, 0, 900, 900)
  image(regular, 300, 450, 255, 447); //netural guy
  let cols = 6;
  let rows = 6;
  let imgWidth = img.width;
  let imgHeight = img.height;

  
  //top text
  textAlign(CENTER);
  textSize(40);
  textFont(fontRegular);
  push();
  fill(0);
  noStroke();
  text('What should I eat today?', 450, 75)
  pop();
  
  //DR PEPPER
  if (mouseX >= 500 && mouseX <= 600 && mouseY >= 145 && mouseY <= 300) {
  //mouse hover
    image(pepper, 450, 125, 200, 200);
  } else {
    image(pepper, 475, 150);
  }
  if (mouseX >= 500 && mouseX <= 600 && mouseY >= 140 && mouseY <= 300 && mouseIsPressed === true) {
  //mouse pressed
    textSize(30);
    image(small, 225, 150, 400, 320);
    text('Dr. Pepper mmmm', 435, 375);
    image(happy, 300, 450, 255, 447);
  }
  
  //SANDVICH
  if (mouseX >= 70 && mouseX <= 230 && mouseY >= 160 && mouseY <= 280) {
  //mouse hover
    image(sandvich, 50, 125, 200, 200);
  } else {
    image(sandvich, 75, 150);
  }
  if (mouseX >= 70 && mouseX <= 230 && mouseY >= 160 && mouseY <= 280 && mouseIsPressed === true) {
  //mouse pressed
    push();
    stroke(255, 0, 0);
    strokeWeight(30);
    animS.line('l1', 10, 70, 160, 230, 280)
    pop();
    image(sad, 300, 450, 255, 447);
    image(small, 225, 150, 400, 320);
    textSize(30);
    push();
    fill(0);
    text('Not in the mood...', 435, 375);
    pop();
  } else {
    animS.reset();
  }
  
  //CRAB
  if (mouseX >= 670 && mouseX <= 820 && mouseY >= 170 && mouseY <= 270) {
  //mouse hover
    image(crab, 650, 125, 200, 200);
    push();
    stroke(230);
    noFill(0);
    animS.circle('c1', 15, 750, 225, 250);
    pop();
  } else {
    image(crab, 675, 150);
    
  }
  if (mouseX >= 670 && mouseX <= 820 && mouseY >= 170 && mouseY <= 270 && mouseIsPressed === true) {
  //mouse pressed
    image(fire, 325, 400, 200, 200)
    image(angry, 300, 450, 255, 447)
    image(small, 210, 125, 415, 350)
    textSize(35);
    text('WHAT IS WRONG', 415, 325);
    text('WITH YOU???', 415, 400)
  }
  
  //BANANA
  //mouse hover
  if (mouseX >= 280 && mouseX <= 420 && mouseY >= 145 && mouseY <= 300) {
    image(banana, 250, 125, 200, 200);
  } else {
    image(banana, 275, 150);
  }
  if (mouseX >= 280 && mouseX <= 420 && mouseY >= 145 && mouseY <= 300 && mouseIsPressed === true) {
  //mouse pressed
    image(fort, 0, 0, 900, 900)
  //for loop/array to create a bunch of bananas
    for (let i = 0; i < cols; i++) {
      for (let j = 0; j < rows; j++) {
      image(img, i * imgWidth, j * imgHeight);
      }
    }
    image(small, 250, 150, 320, 320)
    text('BANANA!!!', 400, 375)
    image(steam, 300, 450, 255, 447)
  }
}